<div class="w-full mb-2">
    <div class="flex items-center">
        <input type="text" name="first_name" placeholder="First Name"
            class="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none"
            value="<?php echo e(old('first_name', $customer->first_name ?? '')); ?>" />
    </div>
    <?php if($errors->has('first_name')): ?>
        <span class="text-sm text-red-400"><?php echo e($errors->first('first_name')); ?></span>
    <?php endif; ?>
</div>

<div class="w-full mb-2">
    <div class="flex items-center">
        <input type="text" name="last_name" placeholder="Last Name"
            class="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none"
            value="<?php echo e(old('last_name', $customer->last_name ?? '')); ?>" />
    </div>
    <?php if($errors->has('last_name')): ?>
        <span class="text-sm text-red-400"><?php echo e($errors->first('last_name')); ?></span>
    <?php endif; ?>
</div>

<div class="w-full mb-2">
    <div class="flex items-center">
        <input type="text" name="email" placeholder="Your Email"
            class="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none"
            value="<?php echo e(old('email', $customer->email ?? '')); ?>" />
    </div>
    <?php if($errors->has('email')): ?>
        <span class="text-sm text-red-400"><?php echo e($errors->first('email')); ?></span>
    <?php endif; ?>
</div>

<div class="w-full mb-2">
    <div class="flex items-center">
        <input type="text" name="phone_no" placeholder="Phone Number"
            class="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none"
            value="<?php echo e(old('phone_no', $customer->phone_no ?? '')); ?>" />
    </div>
    <?php if($errors->has('phone_no')): ?>
        <span class="text-sm text-red-400"><?php echo e($errors->first('phone_no')); ?></span>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Elu\Desktop\WEB\PROJECTS\y-technologies\resources\views/customers/partials/edit_customers_form.blade.php ENDPATH**/ ?>