

<?php $__env->startSection('page_title'); ?>
    New Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-6">
        <div class="w-full flex items-center justify-center ">
            <form class="w-full  my-8 rounded-lg bg-white" action="<?php echo e(url('/orders')); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h2 class="mt-4 mb-5 px-5 text-3xl font-medium opacity-80 text-gray-600 ">
                    Add New Order
                </h2>

                <div class="px-5 pb-10">
                    <?php if($errors->has('custom_error')): ?>
                        <span class="text-sm text-center text-red-400"><?php echo e($errors->first('custom_error')); ?></span>
                    <?php endif; ?>

                    <?php echo $__env->make('orders.partials.orders_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="flex space-x-4">
                        <button type="submit"
                            class="px-6 py-2 mt-8 font-medium text-xl rounded-md opacity-80 bg-primary-700 hover:bg-primary-800 text-gray-100 focus:outline-none">
                            Add Order
                        </button>
                        <a href="<?php echo e(route('orders.index')); ?>"
                            class="px-6 py-2 mt-8 font-medium text-xl rounded-md opacity-80 bg-orange-700 hover:bg-orange-900 text-gray-100 focus:outline-none">
                            Cancel
                        </a>
                    </div>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Elu\Desktop\WEB\PROJECTS\y-technologies\resources\views/orders/new.blade.php ENDPATH**/ ?>