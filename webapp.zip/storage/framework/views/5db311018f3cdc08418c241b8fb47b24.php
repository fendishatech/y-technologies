<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
    <!-- Empty Card 1 -->
    
    
    <div class="p-4 overflow-hidden transform transition-transform duration-300 hover:scale-105">
        <div class="opacity-60 bg-white border-t-4 border-orange-500 rounded-lg shadow-md p-6">
            <a href="/orders?filter=pending">
                <h1 class="text-xl text-gray-600 font-semibold">Active Orders</h1>
                <p class="text-3xl text-orange-700 font-bold"><?php echo e($active_orders); ?></p>
            </a>
        </div>
    </div>

    
    <div class="p-4 overflow-hidden transform transition-transform duration-300 hover:scale-105">
        <div class="opacity-60 bg-white border-t-4 border-green-500 rounded-lg shadow-md p-6">
            <a href="/orders?filter=pending">
                <h1 class="text-1xl text-gray-600 font-semibold">Completed Orders</h1>
                <p class="text-3xl text-green-700 font-bold"><?php echo e($completed_orders); ?></p>
            </a>
        </div>
    </div>

    
    <div class="p-4 overflow-hidden transform transition-transform duration-300 hover:scale-105">
        <div class="opacity-60 bg-white border-t-4 border-primary-500 rounded-lg shadow-md p-6">
            <a href="/orders?filter=pending">
                <h1 class="text-1xl text-gray-600 font-semibold">Sales</h1>
                <p class="text-3xl text-primary-700 font-bold">12</p>
            </a>
        </div>
    </div>

    <!-- Users -->
    <div class="p-4 overflow-hidden transform transition-transform duration-300 hover:scale-105">
        <div class="opacity-60 bg-white border-t-4 border-indigo-500 rounded-lg shadow-md p-6">
            <a href="/orders?filter=pending">
                <h1 class="text-1xl text-gray-600 font-semibold">Employees</h1>
                <p class="text-3xl text-indigo-700 font-bold"><?php echo e($employees); ?></p>
            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Elu\Desktop\WEB\PROJECTS\y-technologies\resources\views/home/partials/stats.blade.php ENDPATH**/ ?>