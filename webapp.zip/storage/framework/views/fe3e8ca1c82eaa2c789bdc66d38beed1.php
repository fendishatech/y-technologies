

<?php $__env->startSection('page_title'); ?>
    Order Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-6">
        <div class="flex flex-col sm:flex-row justify-between items-center">
            <h1 class="my-8 text-primary-600 text-2xl text-left font-semibold">Order Detail</h1>
            <button class="px-4 py-2 rounded-md bg-primary-800 text-white">Generate QR</button>
        </div>
        <div class="my-10 flex gap-8">
            <div class="w-1/2">
                <img src="<?php echo e(asset('storage/' . $order->design_img)); ?>" alt="Design File">
            </div>
            <div class="w-1/2">
                <p>Customer Name: <?php echo e($order->customer->first_name); ?> <?php echo e($order->customer->last_name); ?></p>
                <p>order id : <?php echo e($order->item_id); ?> </p>
                <p>order name : <?php echo e($order->item_name); ?> </p>
                <p>order Quantity : <?php echo e($order->quantity); ?> </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Elu\Desktop\WEB\PROJECTS\y-technologies\resources\views/orders/show.blade.php ENDPATH**/ ?>