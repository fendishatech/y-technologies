<div class="grid grid-cols-1 md:grid-cols-2 gap-x-6">
    <div class="w-full mb-2">
        <div class="flex flex-col items-start">
            <label for="name" class="text-gray-600 px-1 my-2">Product Name</label>
            <input type="text" name="name" placeholder="Product Name"
                class="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none"
                value="<?php echo e(old('name', $product->name)); ?>" />
        </div>
        <?php if($errors->has('name')): ?>
            <span class="text-sm text-red-400"><?php echo e($errors->first('name')); ?></span>
        <?php endif; ?>
    </div>

    <div class="w-full mb-2">
        <div class="flex flex-col items-start">
            <label for="quantity" class="text-gray-600 px-1 my-2">Quantity</label>
            <input type="number" name="quantity" placeholder="Quantity"
                class="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none"
                value="<?php echo e(old('quantity', $product->quantity)); ?>" />
        </div>
        <?php if($errors->has('quantity')): ?>
            <span class="text-sm text-red-400"><?php echo e($errors->first('quantity')); ?></span>
        <?php endif; ?>
    </div>

    <div class="w-full mb-2">
        <div class="flex flex-col items-start">
            <label for="desc" class="text-gray-600 px-1 my-2">Description</label>
            <textarea name="desc" placeholder="Description"
                class="w-full h-24 border rounded px-3 py-2 text-gray-700 focus:outline-none"><?php echo e(old('desc', $product->desc)); ?></textarea>
        </div>
        <?php if($errors->has('desc')): ?>
            <span class="text-sm text-red-400"><?php echo e($errors->first('desc')); ?></span>
        <?php endif; ?>
    </div>

    <div class="w-full mb-2">
        <div class="flex flex-col items-start">
            <label for="price" class="text-gray-600 px-1 my-2">Price</label>
            <input type="number" name="price" step="0.01" placeholder="Price"
                class="w-full border rounded px-3 py-2 text-gray-700 focus:outline-none"
                value="<?php echo e(old('price', $product->price)); ?>" />
        </div>
        <?php if($errors->has('price')): ?>
            <span class="text-sm text-red-400"><?php echo e($errors->first('price')); ?></span>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\Elu\Desktop\WEB\PROJECTS\y-technologies\resources\views/products/partials/edit_form.blade.php ENDPATH**/ ?>