<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Y Technologies | <?php echo $__env->yieldContent('page_title'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="build/assets/app-fb42db8a.css">
    <script src="/build/assets/app-0d91dc04.js" defer></script>
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body class="bg-stone-200">
    <?php echo $__env->make('master.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('master.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="/js/main.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\Elu\Desktop\WEB\PROJECTS\y-technologies\resources\views/master/layout.blade.php ENDPATH**/ ?>