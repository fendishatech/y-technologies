

<?php $__env->startSection('page_title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="container mx-auto my-10 px-6">
        <h1 class="text-2xl text-gray-500 font-semibold">Stats</h1>
        <?php echo $__env->make('home.partials.stats', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <section class="container mx-auto px-6">
        <div class="mt-8 mb-24">
            <h1 class="text-2xl text-gray-500 font-semibold">Orders Table</h1>
            <?php echo $__env->make('home.partials.orders_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="flex justify-between">
                <h1 class="mt-4 text-2xl text-gray-500 font-semibold">Customers Table</h1>
                <a href="<?php echo e(route('customers.index')); ?>">View More</a>
            </div>
            <?php echo $__env->make('home.partials.customers_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <h1 class="mt-4 text-2xl text-gray-500 font-semibold">Users Table</h1>
            <?php echo $__env->make('home.partials.users_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Elu\Desktop\WEB\PROJECTS\y-technologies\resources\views/home/index.blade.php ENDPATH**/ ?>